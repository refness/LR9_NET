﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LR9
{
    class Transport
    {
        protected string brand;
        protected double fuelCost; 

        public virtual void Input()
        {
            Console.Write("Введіть марку: ");
            brand = Console.ReadLine();
            Console.Write("Введіть витрати на пальне (грн): ");
            fuelCost = Convert.ToDouble(Console.ReadLine());
        }

        public virtual double CalculateProfit()
        {
            return 0;
        }

        public virtual void Output()
        {
            Console.WriteLine($"Транспорт: {brand}");
        }
    }

    class CargoTransport : Transport
    {
        private double weight;
        private double pricePerTon;

        public override void Input()
        {
            base.Input();
            Console.Write("Вага вантажу (тонн): ");
            weight = Convert.ToDouble(Console.ReadLine());
            Console.Write("Тариф за тонну (грн): ");
            pricePerTon = Convert.ToDouble(Console.ReadLine());
        }

        public override double CalculateProfit()
        {
            return (weight * pricePerTon) - fuelCost;
        }

        public override void Output()
        {
            base.Output();
            Console.WriteLine($"Тип: Вантажний, Чистий прибуток: {CalculateProfit()} грн");
        }
    }

    class PassengerTransport : Transport
    {
        private int passengers;
        private double ticketPrice;

        public override void Input()
        {
            base.Input();
            Console.Write("Кількість пасажирів: ");
            passengers = Convert.ToInt32(Console.ReadLine());
            Console.Write("Ціна квитка (грн): ");
            ticketPrice = Convert.ToDouble(Console.ReadLine());
        }

        public override double CalculateProfit()
        {
            return (passengers * ticketPrice) - fuelCost;
        }

        public override void Output()
        {
            base.Output();
            Console.WriteLine($"Тип: Пасажирський, Чистий прибуток: {CalculateProfit()} грн");
        }
    }

    class Program
    {
        static void Main()
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Transport cargo = new CargoTransport();
            Console.WriteLine("Вантажний транспорт");
            cargo.Input();

            Transport passenger = new PassengerTransport();
            Console.WriteLine("\nПасажирський транспорт");
            passenger.Input();

            Console.WriteLine("\nРезультат");
            cargo.Output();
            passenger.Output();
        }
    }
}
