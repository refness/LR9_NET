﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LR8_2
{
    class Shape
    {
        public virtual void Input()
        {
            Console.WriteLine("Введення загальних параметрів фігури...");
        }

        public virtual void Draw()
        {
            Console.WriteLine("Малюємо фігуру...");
        }

        public virtual double GetArea()
        {
            return 0;
        }
    }

    class Circle : Shape
    {
        private double radius;

        public override void Input()
        {
            Console.Write("Введіть радіус кола: ");
            radius = Convert.ToDouble(Console.ReadLine());
        }

        public override void Draw()
        {
            Console.WriteLine($"\nКоло з радіусом {radius}");
        }

        public override double GetArea()
        {
            return Math.PI * radius * radius;
        }
    }

    class Square : Shape
    {
        private double side;

        public override void Input()
        {
            Console.Write("Введіть довжину сторони квадрата: ");
            side = Convert.ToDouble(Console.ReadLine());
        }

        public override void Draw()
        {
            Console.WriteLine($"\nКвадрат зі стороною {side}");
        }

        public override double GetArea()
        {
            return side * side;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = System.Text.Encoding.UTF8;

            Shape circle = new Circle();
            Shape square = new Square();

            Console.WriteLine("Коло");
            circle.Input(); 

            Console.WriteLine("\nКвадрат");
            square.Input(); 

            Console.WriteLine("\nРезультат: ");

            Shape[] shapes = { circle, square };

            foreach (var s in shapes)
            {
                s.Draw();
                Console.WriteLine($"Площа фігури: {s.GetArea():F2} кв. од.");
            }
        }
    }
}
